TRUNCATE TABLE [ELULA].[Fact_NYC_Trip] ;

USE [Fact]
GO

DECLARE 
@vPICKUP_DATE DATE ,
@vCOUNT INT = 31 ,
@vINDEX INT = 1 ;

DECLARE @tpickup_date Table (
 DATEID INT IDENTITY(1,1) ,
 PICKUP_DATE DATE 
)

INSERT INTO @tpickup_date
SELECT [FullDateAlternateKey]
FROM [Fact].[ELULA].[DimDate]
where datekey between 20130101 and 20130131

WHILE( @vINDEX <=  @vCOUNT )
BEGIN
	
	SELECT @vPICKUP_DATE = PICKUP_DATE FROM @tpickup_date WHERE DATEID = @vINDEX 

	INSERT INTO [ELULA].[Fact_NYC_Trip]
			   ([medallion]
			   ,[hack_license]
			   ,[pickup_longitude]
			   ,[pickup_latitude]
			   ,[dropoff_longitude]
			   ,[dropoff_latitude]
			   ,[pickup_date]
			   ,[dropoff_date]
			   ,[pickup_time]
			   ,[dropoff_Time]
			   ,[payment_type]
			   ,[rate_code]
			   ,[passenger_count]
			   ,[trip_time_in_secs]
			   ,[trip_distance]
			   ,[fare_amount]
			   ,[surcharge]
			   ,[mta_tax]
			   ,[tip_amount]
			   ,[tolls_amount]
			   ,[total_amount])
		 SELECT 
			  A.[medallion]
			 ,A.[hack_license]
			 ,A.[pickup_longitude]
			 ,A.[pickup_latitude]
			 ,A.[dropoff_longitude]
			 ,A.[dropoff_latitude]
			,CONVERT(DATE,SUBSTRING(a.[pickup_datetime],1,CHARINDEX(' ',a.[pickup_datetime])),23) AS [pickup_date]
			,CONVERT(DATE,SUBSTRING(a.[dropoff_datetime],1,CHARINDEX(' ',a.[dropoff_datetime])),23) AS [dropoff_date]
			,CONVERT(varchar,SUBSTRING(a.[pickup_datetime],CHARINDEX(' ',a.[pickup_datetime]),108)) AS [pickup_time]
			,CONVERT(varchar,SUBSTRING(a.[dropoff_datetime],CHARINDEX(' ',a.[dropoff_datetime]),108)) AS [dropoff_Time]
			,b.[payment_type]
			,a.[rate_code]
			,cast([passenger_count] as int)
			,cast([trip_time_in_secs] as int)
			,cast([trip_distance] as decimal(5,2))
			,cast([fare_amount] as decimal(20,2))
			,cast([surcharge] as decimal(20,2))
			,cast([mta_tax] as decimal(20,2))
			,cast([tip_amount] as decimal(20,2))
			,cast([tolls_amount] as decimal(20,2))
			,cast([total_amount] as decimal(20,2))
		from [dbo].[trip_data_1] A
		INNER JOIN [dbo].[trip_fare_1] B
		ON A.[medallion] = B.[medallion]
		AND A.[hack_license] = B.[hack_license]
		AND A.[pickup_datetime] = B.[pickup_datetime]
		WHERE CONVERT(DATE,SUBSTRING(A.[pickup_datetime],1,CHARINDEX(' ',A.[pickup_datetime])),23) = @vPICKUP_DATE

	SET @vINDEX = @vINDEX + 1
END

GO


