USE [Fact]
GO

/****** Object:  Table [ELULA].[Fact_NYC_Trip]    Script Date: 7/04/2021 11:23:47 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [ELULA].[Fact_NYC_Trip](
	[medallion] [varchar](50) NOT NULL,
	[hack_license] [varchar](50) NOT NULL,
	[pickup_longitude] [varchar](50) NOT NULL,
	[pickup_latitude] [varchar](50) NOT NULL,
	[dropoff_longitude] [varchar](50) NOT NULL,
	[dropoff_latitude] [varchar](50) NOT NULL,
	[pickup_date] [date] NOT NULL,
	[dropoff_date] [date] NOT NULL,
	[pickup_time] [time](7) NOT NULL,
	[dropoff_Time] [time](7) NOT NULL,
	[payment_type] [varchar](50) NULL,
	[rate_code] [varchar](50) NULL,
	[passenger_count] [int] NULL,
	[trip_time_in_secs] [int] NULL,
	[trip_distance] [decimal](5, 2) NULL,
	[fare_amount] [decimal](20, 2) NULL,
	[surcharge] [decimal](20, 2) NULL,
	[mta_tax] [decimal](20, 2) NULL,
	[tip_amount] [decimal](20, 2) NULL,
	[tolls_amount] [decimal](20, 2) NULL,
	[total_amount] [decimal](20, 2) NULL,
 CONSTRAINT [PK_Fact_NYC_Trip] PRIMARY KEY CLUSTERED 
(
	[medallion] ASC,
	[hack_license] ASC,
	[pickup_longitude] ASC,
	[pickup_latitude] ASC,
	[dropoff_longitude] ASC,
	[dropoff_latitude] ASC,
	[pickup_date] ASC,
	[dropoff_date] ASC,
	[pickup_time] ASC,
	[dropoff_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

CREATE TABLE [ELULA].[Agg_NYC_Trip_By_Date](
	[medallion] [varchar](50) NOT NULL,
	[hack_license] [varchar](50) NOT NULL,
	[pickup_date] [date] NOT NULL,
	[dropoff_date] [date] NOT NULL,
	[payment_type] [varchar](50) NULL,
	[rate_code] [varchar](50) NULL,
	[passenger_count] [int] NULL,
	[trip_time_in_secs] [int] NULL,
	[trip_distance] [decimal](38, 2) NULL,
	[fare_amount] [decimal](38, 2) NULL,
	[surcharge] [decimal](38, 2) NULL,
	[mta_tax] [decimal](38, 2) NULL,
	[tip_amount] [decimal](38, 2) NULL,
	[tolls_amount] [decimal](38, 2) NULL,
	[total_amount] [decimal](38, 2) NULL
) ON [PRIMARY]
GO



